BPMN files are not yet available for the child health in emergencies business processes.

If you would like versions to be shared in MS Visio format, please write to CCC@who.int