# DDCCTXSHEbundleexampleFrench - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DDCCTXSHEbundleexampleFrench**

## Example Bundle: DDCCTXSHEbundleexampleFrench



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DDCCTXSHEbundleexampleFrench",
  "meta" : {
    "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCSubmitHealthEventRequest"]
  },
  "type" : "batch",
  "entry" : [{
    "fullUrl" : "http://www.example.org/fhir/Parameters/DDCCVSTXSHEParametersFrench",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "DDCCVSTXSHEParametersFrench",
      "meta" : {
        "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCGenerateHealthCertificateParameters"]
      },
      "parameter" : [{
        "name" : "response",
        "resource" : {
          "resourceType" : "QuestionnaireResponse",
          "id" : "DDCCVSQuestionnaireResponseFrench",
          "meta" : {
            "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCQuestionnaireResponse"]
          },
          "questionnaire" : "http://smart.who.int/ddcc/DDCCVSCoreDataSetQuestionnaire",
          "status" : "completed",
          "subject" : {
            "reference" : "Patient/DDCCPatientFrench"
          },
          "authored" : "2021-04-01",
          "item" : [{
            "linkId" : "name",
            "answer" : [{
              "valueString" : "Aulus Agerius"
            }]
          },
          {
            "linkId" : "birthDate",
            "answer" : [{
              "valueDate" : "2003-03-03"
            }]
          },
          {
            "linkId" : "identifier",
            "answer" : [{
              "valueString" : "12345678902"
            }]
          },
          {
            "linkId" : "sex",
            "answer" : [{
              "valueCoding" : {
                "system" : "http://hl7.org/fhir/administrative-gender",
                "code" : "male"
              }
            }]
          },
          {
            "linkId" : "vaccine",
            "answer" : [{
              "valueCoding" : {
                "system" : "http://id.who.int/icd11/mms",
                "code" : "XM0GQ8"
              }
            }]
          },
          {
            "linkId" : "brand",
            "answer" : [{
              "valueCoding" : {
                "system" : "http://id.who.int/icd11/mms",
                "code" : "XM8NQ0"
              }
            }]
          },
          {
            "linkId" : "manufacturer",
            "answer" : [{
              "valueCoding" : {
                "system" : "http://smart.who.int/ddcc/CodeSystem/DDCCExampleTestCodeSystem",
                "code" : "TEST"
              }
            }]
          },
          {
            "linkId" : "ma_holder",
            "answer" : [{
              "valueCoding" : {
                "system" : "http://smart.who.int/ddcc/CodeSystem/DDCCExampleTestCodeSystem",
                "code" : "TEST"
              }
            }]
          },
          {
            "linkId" : "lot",
            "answer" : [{
              "valueString" : "ER8732"
            }]
          },
          {
            "linkId" : "date",
            "answer" : [{
              "valueDate" : "2021-04-05"
            }]
          },
          {
            "linkId" : "vaccine_valid",
            "answer" : [{
              "valueDate" : "2021-04-19"
            }]
          },
          {
            "linkId" : "dose",
            "answer" : [{
              "valueInteger" : 1
            }]
          },
          {
            "linkId" : "total_doses",
            "answer" : [{
              "valueInteger" : 2
            }]
          },
          {
            "linkId" : "country",
            "answer" : [{
              "valueCoding" : {
                "system" : "urn:iso:std:iso:3166",
                "code" : "FRA"
              }
            }]
          },
          {
            "linkId" : "centre",
            "answer" : [{
              "valueString" : "Site de vaccination"
            }]
          },
          {
            "linkId" : "hw",
            "answer" : [{
              "valueString" : "lAH8TnzqAInqwkslHzOlSA"
            }]
          },
          {
            "linkId" : "disease",
            "answer" : [{
              "valueCoding" : {
                "system" : "http://id.who.int/icd11/mms",
                "code" : "RA01"
              }
            }]
          },
          {
            "linkId" : "due_date",
            "answer" : [{
              "valueDate" : "2021-04-28"
            }]
          },
          {
            "linkId" : "pha",
            "answer" : [{
              "valueString" : "dPD2PfwzBQyphcjeUiAdRP"
            }]
          },
          {
            "linkId" : "hcid",
            "answer" : [{
              "valueString" : "bMlJkAt0V92RYhhG3fNt2"
            }]
          },
          {
            "linkId" : "valid_from",
            "answer" : [{
              "valueDate" : "2021-04-05"
            }]
          },
          {
            "linkId" : "valid_until",
            "answer" : [{
              "valueDate" : "2022-04-05"
            }]
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "QuestionnaireResponse/$generateHealthCertificate"
    }
  }]
}

```
