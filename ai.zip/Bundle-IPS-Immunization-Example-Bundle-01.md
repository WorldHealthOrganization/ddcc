# IPS-Immunization-Example-Bundle-01 - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IPS-Immunization-Example-Bundle-01**

## Bundle: IPS-Immunization-Example-Bundle-01



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "IPS-Immunization-Example-Bundle-01",
  "type" : "collection",
  "timestamp" : "2021-04-30T00:00:00.000Z",
  "entry" : [{
    "fullUrl" : "urn:uuid:afd2a258-c0fb-4a41-a337-263e9efd9936",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "afd2a258-c0fb-4a41-a337-263e9efd9936",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_afd2a258-c0fb-4a41-a337-263e9efd9936\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient afd2a258-c0fb-4a41-a337-263e9efd9936</b></p><a name=\"afd2a258-c0fb-4a41-a337-263e9efd9936\"> </a><a name=\"hcafd2a258-c0fb-4a41-a337-263e9efd9936\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Marie Lux-Brennard  Female, DoB: 1998-04-17 ( urn:oid:1.3.182.4.4#1998041799999)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\"><a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:uuid:647515ed-0d5e-4c99-b23d-073fbc593f76</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:oid:1.3.182.4.4",
        "value" : "1998041799999"
      },
      {
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:647515ed-0d5e-4c99-b23d-073fbc593f76"
      }],
      "name" : [{
        "family" : "Lux-Brennard",
        "given" : ["Marie"]
      }],
      "gender" : "female",
      "birthDate" : "1998-04-17"
    }
  },
  {
    "fullUrl" : "urn:uuid:52e23edf-f8d0-4386-a50b-a4750bb4f0b9",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "52e23edf-f8d0-4386-a50b-a4750bb4f0b9",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_52e23edf-f8d0-4386-a50b-a4750bb4f0b9\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization 52e23edf-f8d0-4386-a50b-a4750bb4f0b9</b></p><a name=\"52e23edf-f8d0-4386-a50b-a4750bb4f0b9\"> </a><a name=\"hc52e23edf-f8d0-4386-a50b-a4750bb4f0b9\"> </a><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://id.who.int/icd11/mms XM6AT1}\">COVID-19 vaccine, DNA based</span></p><p><b>patient</b>: <a href=\"Bundle-IPS-Immunization-Example-Bundle-01.html#Patient_afd2a258-c0fb-4a41-a337-263e9efd9936\">Marie Lux-Brennard  Female, DoB: 1998-04-17 ( urn:oid:1.3.182.4.4#1998041799999)</a></p><p><b>occurrence</b>: 2021-04-21 00:00:00+0200</p><p><b>primarySource</b>: true</p><p><b>lotNumber</b>: AXK23RWERS</p><p><b>expirationDate</b>: 2021-06-01</p></div>"
      },
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://id.who.int/icd11/mms",
          "code" : "XM6AT1",
          "display" : "COVID-19 vaccine, DNA based"
        }],
        "text" : "COVID-19 vaccine, DNA based"
      },
      "patient" : {
        "reference" : "Patient/afd2a258-c0fb-4a41-a337-263e9efd9936"
      },
      "occurrenceDateTime" : "2021-04-21T00:00:00+02:00",
      "primarySource" : true,
      "lotNumber" : "AXK23RWERS",
      "expirationDate" : "2021-06-01"
    }
  }]
}

```
