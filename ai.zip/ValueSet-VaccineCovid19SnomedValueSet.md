# Vaccine - COVID-19 - SNOMED CT - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Vaccine - COVID-19 - SNOMED CT**

## ValueSet: Vaccine - COVID-19 - SNOMED CT (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/ValueSet/VaccineCovid19SnomedValueSet | *Version*:1.0.0 |
| Draft as of 2026-09-05 | *Computable Name*:VaccineCovid19SnomedValueSet |

 
This is a one-time snapshot of the allowed SNOMED values for vaccines, retrieved in February 2023. Contents may need to be updated and readers should consult the documentation, found here http://hl7.org/fhir/uv/shc-vaccination/2021Sep/ValueSet-vaccine-snomed.html 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "VaccineCovid19SnomedValueSet",
  "url" : "http://smart.who.int/ddcc/ValueSet/VaccineCovid19SnomedValueSet",
  "version" : "1.0.0",
  "name" : "VaccineCovid19SnomedValueSet",
  "title" : "Vaccine - COVID-19 - SNOMED CT",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-09-05T20:45:54+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "This is a one-time snapshot of the allowed SNOMED values for vaccines, retrieved in February 2023. Contents may need to be updated and readers should consult the documentation, found here http://hl7.org/fhir/uv/shc-vaccination/2021Sep/ValueSet-vaccine-snomed.html",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "1031000172108",
        "display" : "COVID-19 mRNA vaccine (BNT162b2) of Pfizer-BioNTech"
      },
      {
        "code" : "10871000172106",
        "display" : "COVID-19 mRNA vaccine (mRNA-1273) of Moderna"
      },
      {
        "code" : "10891000172107",
        "display" : "COVID-19 viral vector vaccine (AZD1222 (ChAdOx1-S recombinant)) of AstraZeneca, Oxford"
      },
      {
        "code" : "10901000172106",
        "display" : "COVID-19 viral vector vaccine (JNJ-78436735( Ad26.COV2-S recombinant)) of Johnson and Johnson, Janssens"
      },
      {
        "code" : "125071000220108",
        "display" : "COVID-19 mRNA Vaccine Pfizer-BioNTech 10 micrograms/dose concentrate for dispersion for injection"
      },
      {
        "code" : "125081000220106",
        "display" : "COVID-19 mRNA Vaccine Ready to Use Pfizer-BioNTech 30 micrograms/ 0.3 milliliter dose dispersion for injection"
      },
      {
        "code" : "125091000220109",
        "display" : "COVID-19 mRNA Ready to Use Adapted BA.1 Vaccine Pfizer-BioNTech 15 / 15 micrograms/ 0.3 milliliter dose dispersion for injection"
      },
      {
        "code" : "125101000220104",
        "display" : "COVID-19 mRNA Ready to Use Adapted BA.4 and BA.5 Vaccine Pfizer-BioNTech 15 / 15 micrograms/ 0.3 milliliter dose dispersion for injection"
      },
      {
        "code" : "125111000220101",
        "display" : "COVID-19 mRNA Adapted BA.1 Vaccine Moderna (50 micrograms/50 micrograms) / milliliter dispersion for injection"
      },
      {
        "code" : "125121000220108",
        "display" : "COVID-19 mRNA Adapted BA.4 nd BA.5 Vaccine Moderna (50 micrograms/50 micrograms) / milliliter dispersion for injection"
      },
      {
        "code" : "1401000220108",
        "display" : "COVID-19 Vaccine AstraZeneca 5 x10,000,000,000 viral particles/per 0.5ml dose for injection multidose vials"
      },
      {
        "code" : "1411000220106",
        "display" : "COVID-19 mRNA Vaccine Pfizer-BioNTech 30 micrograms per 0.3ml dose concentrate for suspension for injection multidose vials"
      },
      {
        "code" : "1421000220104",
        "display" : "COVID-19 mRNA Vaccine Moderna 0.1mg per 0.5mL dose dispersion for injection multidose vials"
      },
      {
        "code" : "28571000087109",
        "display" : "COVID-19 SPIKEVAX 0.20 mg/mL mRNA Mod"
      },
      {
        "code" : "28581000087106",
        "display" : "COVID-19 COMIRNATY 30 mcg/0.3 ml mRNA PB"
      },
      {
        "code" : "28761000087108",
        "display" : "COVID-19 VAXZEVRIA AZC"
      },
      {
        "code" : "28951000087107",
        "display" : "COVID-19 JANSSEN COVID-19 VACCINE Jan"
      },
      {
        "code" : "28961000087105",
        "display" : "COVID-19 COVISHIELD VP"
      },
      {
        "code" : "29171000087106",
        "display" : "COVID-19 NUVAXOVID NOV"
      },
      {
        "code" : "30151000087105",
        "display" : "COVID-19 COVIFENZ VLP MED"
      },
      {
        "code" : "31301000087101",
        "display" : "COVID-19 SINOPHARM-BIBP"
      },
      {
        "code" : "31311000087104",
        "display" : "COVID-19 CoronaVac"
      },
      {
        "code" : "31341000087103",
        "display" : "COVID-19 Sputnik V"
      },
      {
        "code" : "31431000087100",
        "display" : "COVID-19 Convidecia"
      },
      {
        "code" : "33201000087108",
        "display" : "COVID-19 SINOPHARM-WIBP"
      },
      {
        "code" : "33211000087105",
        "display" : "COVID-19 COVAXIN"
      },
      {
        "code" : "33221000087102",
        "display" : "COVID-19 mRNA CureVac"
      },
      {
        "code" : "33361000087101",
        "display" : "COVID-19 COMIRNATY pediatric 10 mcg/0.2 ml mRNA PB"
      },
      {
        "code" : "33391000087109",
        "display" : "COVID-19 Abdala"
      },
      {
        "code" : "33401000087107",
        "display" : "COVID-19 COVIran Barekat"
      },
      {
        "code" : "33411000087109",
        "display" : "COVID-19 CoviVac"
      },
      {
        "code" : "33421000087101",
        "display" : "COVID-19 EpiVacCorona"
      },
      {
        "code" : "33431000087104",
        "display" : "COVID-19 KCONVAC"
      },
      {
        "code" : "33441000087105",
        "display" : "COVID-19 Medgen-Dynavax-NIAID"
      },
      {
        "code" : "33451000087108",
        "display" : "COVID-19 QazCovid-in"
      },
      {
        "code" : "33461000087106",
        "display" : "COVID-19 Sputnik Light"
      },
      {
        "code" : "33471000087102",
        "display" : "COVID-19 ZIFIVAX"
      },
      {
        "code" : "33581000087104",
        "display" : "COVID-19 pediatric mRNA unspecified"
      },
      {
        "code" : "33881000087102",
        "display" : "COVID-19 COMIRNATY tris-sucrose 30 mcg/0.3 ml mRNA PB"
      },
      {
        "code" : "34591000087100",
        "display" : "COVID-19 Soberana 02"
      },
      {
        "code" : "34601000087108",
        "display" : "COVID-19 SpikoGen"
      },
      {
        "code" : "34611000087105",
        "display" : "COVID-19 COMIRNATY pediatric 3 mcg/0.2 ml mRNA PB"
      },
      {
        "code" : "34921000087108",
        "display" : "COVID-19 COVOVAX"
      },
      {
        "code" : "35651000087105",
        "display" : "COVID-19 SPIKEVAX 0.10 mg/mL mRNA Mod"
      },
      {
        "code" : "37311000087109",
        "display" : "COVID-19 SPIKEVAX Bivalent (Original / Omicron BA.1) 0.10 mg/mL mRNA Mod"
      },
      {
        "code" : "37651000087101",
        "display" : "COVID-19 SPIKEVAX Bivalent (Original / Omicron BA.4/BA.5) 0.10 mg/mL mRNA Mod"
      },
      {
        "code" : "384671000221101",
        "display" : "SINOPHARM - BIBP vacuna COVID-19 [SARS-COV-2 (cÃ©lulas Vero) inactivado 1 dosis/0,5 ml] suspensiÃ³n inyectable, vial de 0,5 ml (1 dosis), Sinopharm - Beijing Institute"
      },
      {
        "code" : "399651000221108",
        "display" : "vacuna COVID-19 virus entero inactivado 1 dosis/0,5 ml, suspensiÃ³n inyectable, vial de 0,5 ml (1 dosis)"
      },
      {
        "code" : "399661000221105",
        "display" : "vacuna COVID-19 vector no replicante adenovirus de chimpancÃ© 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 5 ml (10 dosis)"
      },
      {
        "code" : "399681000221103",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 5 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 3 ml (5 dosis)"
      },
      {
        "code" : "399691000221100",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 26 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 3 ml (5 dosis)"
      },
      {
        "code" : "399701000221100",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 26 1 dosis/0,5 ml, suspensiÃ³n inyectable, vial de 3 ml (5 dosis)"
      },
      {
        "code" : "399771000221108",
        "display" : "COVISHIELD vacuna COVID-19 [ChAdOx1 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 5 ml (10 dosis), Serum Institute of India"
      },
      {
        "code" : "399781000221106",
        "display" : "VAXZEVRIA vacuna COVID-19 [ChAdOx1 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 5 ml (10 dosis), Astrazeneca"
      },
      {
        "code" : "399801000221105",
        "display" : "SPUTNIK V vacuna COVID-19 componente I [rAd 26 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 3 ml (5 dosis), Instituto Gamaleya"
      },
      {
        "code" : "399811000221108",
        "display" : "SPUTNIK V vacuna COVID-19 componente II [rAd 5 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 3 ml (5 dosis), Instituto Gamaleya"
      },
      {
        "code" : "399821000221103",
        "display" : "JANSSEN vacuna COVID-19 [rAd 26 SARS-CoV-2 S 1 dosis/0,5 ml] suspensiÃ³n inyectable, vial de 3 ml (5 dosis), Janssen"
      },
      {
        "code" : "399861000221106",
        "display" : "vacuna COVID-19 ARNm 100 mcg/ml, suspensiÃ³n inyectable, vial de 5,5 ml (10 dosis de 0,5 ml)"
      },
      {
        "code" : "399871000221102",
        "display" : "vacuna COVID-19 ARNm 100 mcg/ml, suspensiÃ³n inyectable, vial de 7,5 ml (15 dosis de 0,5 ml)"
      },
      {
        "code" : "399881000221104",
        "display" : "vacuna COVID-19 ARNm 30 mcg/0,3 ml, suspensiÃ³n inyectable, vial de 0,45 ml (6 dosis de 0,3 ml luego de diluciÃ³n)"
      },
      {
        "code" : "399891000221101",
        "display" : "SPIKEVAX vacuna COVID-19 [SARS-CoV-2 S ARNm 100 mcg/0,5 ml] suspensiÃ³n inyectable, vial de 5.5 ml (10 dosis), Moderna"
      },
      {
        "code" : "399901000221102",
        "display" : "SPIKEVAX vacuna COVID-19 [SARS-CoV-2 S ARNm 100 mcg/0,5 ml] suspensiÃ³n inyectable, vial de 7,5 ml (15 dosis de 0,5 ml), Moderna"
      },
      {
        "code" : "399911000221104",
        "display" : "COMIRNATY vacuna COVID-19 [SARS-CoV-2 S ARNm 30 mcg/0,3 ml] suspensiÃ³n inyectable, vial de 0,45 ml (6 dosis de 0,3 ml luego de diluciÃ³n), Pfizer"
      },
      {
        "code" : "424531000221101",
        "display" : "vacuna COVID-19 virus entero inactivado 1 dosis/0,5 ml, suspensiÃ³n inyectable"
      },
      {
        "code" : "424541000221108",
        "display" : "vacuna COVID-19 virus entero inactivado 1 dosis/0,5 ml, suspensiÃ³n inyectable, vial de 1 ml (2 dosis)"
      },
      {
        "code" : "424551000221105",
        "display" : "SINOPHARM - BIBP vacuna COVID-19 [SARS-COV-2 (cÃ©lulas Vero) inactivado 1 dosis/0,5 ml] suspensiÃ³n inyectable, vial de 1 ml (2 dosis), Sinopharm - Beijing Institute"
      },
      {
        "code" : "424561000221107",
        "display" : "vacuna COVID-19 vector no replicante adenovirus de chimpancÃ© 1 dosis/0,5 ml, soluciÃ³n inyectable"
      },
      {
        "code" : "424571000221103",
        "display" : "VAXZEVRIA vacuna COVID-19 vector viral no replicante"
      },
      {
        "code" : "424581000221100",
        "display" : "COVISHIELD vacuna COVID-19 vector viral no replicante"
      },
      {
        "code" : "424591000221102",
        "display" : "JANSSEN vacuna COVID-19 vector viral no replicante"
      },
      {
        "code" : "424601000221107",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 26 1 dosis/0,5 ml, suspensiÃ³n inyectable"
      },
      {
        "code" : "424611000221105",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 26 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 0,5 ml (1 dosis)"
      },
      {
        "code" : "424621000221100",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 26 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 1 ml (2 dosis)"
      },
      {
        "code" : "424631000221102",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 26 1 dosis/0,5 ml, soluciÃ³n inyectable"
      },
      {
        "code" : "424641000221109",
        "display" : "SPUTNIK V vacuna COVID-19 componente I [rAd 26 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 0,5 ml (1 dosis), Instituto Gamaleya"
      },
      {
        "code" : "424651000221106",
        "display" : "SPUTNIK V vacuna COVID-19 componente I [rAd 26 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 1 ml (2 dosis), Instituto Gamaleya"
      },
      {
        "code" : "424661000221108",
        "display" : "SPUTNIK V vacuna COVID-19 componente II [rAd 5 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 1 ml (2 dosis), Instituto Gamaleya"
      },
      {
        "code" : "424671000221104",
        "display" : "SPUTNIK V vacuna COVID-19 componente II [rAd 5 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 0,5 ml (1 dosis), Instituto Gamaleya"
      },
      {
        "code" : "424681000221101",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 5 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 1 ml (2 dosis)"
      },
      {
        "code" : "424691000221103",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 5 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 0,5 ml (1 dosis)"
      },
      {
        "code" : "424701000221103",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 5 1 dosis/0,5 ml, soluciÃ³n inyectable"
      },
      {
        "code" : "424711000221100",
        "display" : "SPUTNIK V vacuna COVID-19 vector viral no replicante"
      },
      {
        "code" : "424721000221105",
        "display" : "vacuna COVID-19 ARNm 100 mcg/0,5 ml, suspensiÃ³n inyectable"
      },
      {
        "code" : "424731000221108",
        "display" : "SPIKEVAX vacuna COVID-19 ARNm"
      },
      {
        "code" : "424741000221101",
        "display" : "vacuna COVID-19 ARNm 30 mcg/0,3 ml, suspensiÃ³n inyectable"
      },
      {
        "code" : "424751000221104",
        "display" : "COMIRNATY vacuna COVID-19 ARNm"
      },
      {
        "code" : "424781000221109",
        "display" : "CONVIDECIA vacuna COVID-19 [rAd 5 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 0,5 ml, (1 dosis), Cansino"
      },
      {
        "code" : "424791000221107",
        "display" : "CONVIDECIA vacuna COVID-19 [rAd 5 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 1,5 ml (3 dosis), Cansino"
      },
      {
        "code" : "424801000221108",
        "display" : "vacuna COVID-19 vector no replicante Adenovirus humano 5 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 1,5 ml (3 dosis)"
      },
      {
        "code" : "424821000221101",
        "display" : "SPUTNIK LIGTH vacuna COVID-19 vector viral no replicante"
      },
      {
        "code" : "424831000221103",
        "display" : "NOVAVAX vacuna COVID-19 proteÃ­na de espiga recombinante"
      },
      {
        "code" : "424971000221108",
        "display" : "ZYDUS CADILA vacuna COVID-19 ADN"
      },
      {
        "code" : "425001000221100",
        "display" : "SPUTNIK V componente I vacuna COVID-19 vector viral no replicante rAd 26"
      },
      {
        "code" : "425011000221102",
        "display" : "SPUTNIK V componente II vacuna COVID-19 vector viral no replicante rAd 5"
      },
      {
        "code" : "425031000221105",
        "display" : "VAXZEVRIA vacuna COVID-19 [ChAdOx1 SARS-CoV-2 S 1 dosis/0,5 ml] soluciÃ³n inyectable, vial de 4 ml (8 dosis), Astrazeneca"
      },
      {
        "code" : "425051000221101",
        "display" : "vacuna que contiene vector adenovirus de chimpancÃ© no replicante que codifica proteÃ­na de espiga de SARS-CoV-2 1 dosis/0,5 ml, soluciÃ³n inyectable, vial de 4 ml (8 dosis)"
      },
      {
        "code" : "62051000220105",
        "display" : "Janssen COVID-19 Vaccine 0.5 millilitre suspension injection Janssen Inc"
      }]
    }]
  }
}

```
