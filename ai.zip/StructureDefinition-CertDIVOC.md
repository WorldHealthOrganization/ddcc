# Certificate - DIVOC Verifiable Credential Logical Model - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Certificate - DIVOC Verifiable Credential Logical Model**

## Logical Model: Certificate - DIVOC Verifiable Credential Logical Model ( Abstract ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/StructureDefinition/CertDIVOC | *Version*:1.0.0 |
| Draft as of 2026-09-05 | *Computable Name*:CertDIVOC |

 
Data elements for the DIVOC Core Data Set. 
The official DIVOC documentation appears to be at [https://divoc.digit.org](https://divoc.digit.org). However, this does not include a full list of elements included in DIVOC certificates. 
There is a JSON-LD context referenced in DIVOC certificate examples (`https://cowin.gov.in/credentials/vaccination/v1`), which would provide some element-level information, but this URL does not resolve. There is a copy of this JSON-LD context at [https://github.com/egovernments/DIVOC/blob/main/vaccination-context/vaccination-context.js](https://github.com/egovernments/DIVOC/blob/main/vaccination-context/vaccination-context.js). 
It was not possible to find any online documentation regarding DIVOC proof of testing. Information on this was provided by the DIVOC team via email. 
Some element descriptions in this logical model provide details that are not in publicly available DIVOC documentation. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/who.ddcc|current/StructureDefinition/StructureDefinition-CertDIVOC.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-CertDIVOC.csv), [Excel](StructureDefinition-CertDIVOC.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CertDIVOC",
  "url" : "http://smart.who.int/ddcc/StructureDefinition/CertDIVOC",
  "version" : "1.0.0",
  "name" : "CertDIVOC",
  "title" : "Certificate - DIVOC Verifiable Credential Logical Model",
  "status" : "draft",
  "date" : "2026-09-05T20:45:54+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Data elements for the DIVOC Core Data Set.\n\nThe official DIVOC documentation appears to be at <https://divoc.digit.org>. However, this does not include a full list of elements included in DIVOC certificates.\n\nThere is a JSON-LD context referenced in DIVOC certificate examples (`https://cowin.gov.in/credentials/vaccination/v1`), which would provide some element-level information, but this URL does not resolve. There is a copy of this JSON-LD context at <https://github.com/egovernments/DIVOC/blob/main/vaccination-context/vaccination-context.js>.\n\nIt was not possible to find any online documentation regarding DIVOC proof of testing. Information on this was provided by the DIVOC team via email.\n\nSome element descriptions in this logical model provide details that are not in publicly available DIVOC documentation.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : true,
  "type" : "http://smart.who.int/ddcc/StructureDefinition/CertDIVOC",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "CertDIVOC",
      "path" : "CertDIVOC",
      "short" : "Certificate - DIVOC Verifiable Credential Logical Model",
      "definition" : "Data elements for the DIVOC Core Data Set.\n\nThe official DIVOC documentation appears to be at <https://divoc.digit.org>. However, this does not include a full list of elements included in DIVOC certificates.\n\nThere is a JSON-LD context referenced in DIVOC certificate examples (`https://cowin.gov.in/credentials/vaccination/v1`), which would provide some element-level information, but this URL does not resolve. There is a copy of this JSON-LD context at <https://github.com/egovernments/DIVOC/blob/main/vaccination-context/vaccination-context.js>.\n\nIt was not possible to find any online documentation regarding DIVOC proof of testing. Information on this was provided by the DIVOC team via email.\n\nSome element descriptions in this logical model provide details that are not in publicly available DIVOC documentation."
    },
    {
      "id" : "CertDIVOC.context",
      "path" : "CertDIVOC.context",
      "short" : "Context (JSON-LD) - should actually be `@context` but this name isn't supported by FHIR.",
      "definition" : "Context (JSON-LD) - should actually be `@context` but this name isn't supported by FHIR.",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.type",
      "path" : "CertDIVOC.type",
      "short" : "Type",
      "definition" : "JSON-LD Type",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.issuer",
      "path" : "CertDIVOC.issuer",
      "short" : "Issuer identifier",
      "definition" : "Issuer identifier URI. generally a DID",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.issuanceDate",
      "path" : "CertDIVOC.issuanceDate",
      "short" : "issuanceDate",
      "definition" : "Date and time when a credential becomes valid",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "CertDIVOC.nonTransferable",
      "path" : "CertDIVOC.nonTransferable",
      "short" : "Non Trasnferability",
      "definition" : "indicates that a verifiable credential must only be encapsulated into a verifiable presentation whose proof was issued by the credentialSubject",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject",
      "path" : "CertDIVOC.credentialSubject",
      "short" : "CredentialSubject",
      "definition" : "Contains claims about one or more objects (Patients)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.type",
      "path" : "CertDIVOC.credentialSubject.type",
      "short" : "type",
      "definition" : "Type of credential. Generally 'Person'",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.uhid",
      "path" : "CertDIVOC.credentialSubject.uhid",
      "short" : "another id",
      "definition" : "another id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.refId",
      "path" : "CertDIVOC.credentialSubject.refId",
      "short" : "reference id",
      "definition" : "reference id",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.name",
      "path" : "CertDIVOC.credentialSubject.name",
      "short" : "A name associated with the patient",
      "definition" : "A name associated with the patient",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.gender",
      "path" : "CertDIVOC.credentialSubject.gender",
      "short" : "Gender (`Male` or `Female`; unknown if there are other options)",
      "definition" : "Gender (`Male` or `Female`; unknown if there are other options)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.sex",
      "path" : "CertDIVOC.credentialSubject.sex",
      "short" : "Sex (not used in examples; presumably `Male` or `Female`; unknown if there are other options)",
      "definition" : "Sex (not used in examples; presumably `Male` or `Female`; unknown if there are other options)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.age",
      "path" : "CertDIVOC.credentialSubject.age",
      "short" : "Age",
      "definition" : "Age",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.dob",
      "path" : "CertDIVOC.credentialSubject.dob",
      "short" : "The date of birth for the individual (V2 only)",
      "definition" : "The date of birth for the individual (V2 only)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.nationality",
      "path" : "CertDIVOC.credentialSubject.nationality",
      "short" : "Nationality",
      "definition" : "Nationality",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address",
      "path" : "CertDIVOC.credentialSubject.address",
      "short" : "Address",
      "definition" : "Address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.streetAddress",
      "path" : "CertDIVOC.credentialSubject.address.streetAddress",
      "short" : "Line 1 of the address",
      "definition" : "Line 1 of the address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.streetAddress2",
      "path" : "CertDIVOC.credentialSubject.address.streetAddress2",
      "short" : "Line 2 of the address",
      "definition" : "Line 2 of the address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.district",
      "path" : "CertDIVOC.credentialSubject.address.district",
      "short" : "District name (aka county)",
      "definition" : "District name (aka county)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.city",
      "path" : "CertDIVOC.credentialSubject.address.city",
      "short" : "Name of city, town etc.",
      "definition" : "Name of city, town etc.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.addressRegion",
      "path" : "CertDIVOC.credentialSubject.address.addressRegion",
      "short" : "Sub-unit of country (abbreviations ok)",
      "definition" : "Sub-unit of country (abbreviations ok)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.addressCountry",
      "path" : "CertDIVOC.credentialSubject.address.addressCountry",
      "short" : "Country (e.g. may be ISO 3166 2 or 3 letter code)",
      "definition" : "Country (e.g. may be ISO 3166 2 or 3 letter code)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.credentialSubject.address.postalCode",
      "path" : "CertDIVOC.credentialSubject.address.postalCode",
      "short" : "Postal code for area",
      "definition" : "Postal code for area",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence",
      "path" : "CertDIVOC.evidence",
      "short" : "Evidence",
      "definition" : "Vaccination Information",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.feedbackUrl",
      "path" : "CertDIVOC.evidence.feedbackUrl",
      "short" : "URL for feedback",
      "definition" : "URL for feedback",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.infoUrl",
      "path" : "CertDIVOC.evidence.infoUrl",
      "short" : "URL for more information on this record",
      "definition" : "URL for more information on this record",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.certificateId",
      "path" : "CertDIVOC.evidence.certificateId",
      "short" : "Certificate Unique Identifier",
      "definition" : "Certificate Unique Identifier",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.type",
      "path" : "CertDIVOC.evidence.type",
      "short" : "type",
      "definition" : "Type of evidence record. Generally `Vaccination` or `TestDetails`",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.batch",
      "path" : "CertDIVOC.evidence.batch",
      "short" : "Vaccine lot number",
      "definition" : "Vaccine lot number",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.vaccine",
      "path" : "CertDIVOC.evidence.vaccine",
      "short" : "Vaccine description. Might include vaccine type and brand",
      "definition" : "Vaccine description. Might include vaccine type and brand",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.manufacturer",
      "path" : "CertDIVOC.evidence.manufacturer",
      "short" : "Name of the Vaccine/Test Manufacturer",
      "definition" : "Name of the Vaccine/Test Manufacturer",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.date",
      "path" : "CertDIVOC.evidence.date",
      "short" : "Date of immunization",
      "definition" : "Date of immunization",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.effectiveStart",
      "path" : "CertDIVOC.evidence.effectiveStart",
      "short" : "Effective immunization start date",
      "definition" : "Effective immunization start date",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.effectiveUntil",
      "path" : "CertDIVOC.evidence.effectiveUntil",
      "short" : "Effective immunization end date",
      "definition" : "Effective immunization end date",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.dose",
      "path" : "CertDIVOC.evidence.dose",
      "short" : "Dose Number",
      "definition" : "Dose Number",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "positiveInt"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.totalDoses",
      "path" : "CertDIVOC.evidence.totalDoses",
      "short" : "Total doses for this vaccine protocol regimen",
      "definition" : "Total doses for this vaccine protocol regimen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "positiveInt"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.verifier",
      "path" : "CertDIVOC.evidence.verifier",
      "short" : "Verifier",
      "definition" : "Practitioner that oversaw the application",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.verifier.name",
      "path" : "CertDIVOC.evidence.verifier.name",
      "short" : "Name of the practitioner",
      "definition" : "Name of the practitioner",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility",
      "path" : "CertDIVOC.evidence.facility",
      "short" : "Facility",
      "definition" : "Facility where the immunization took place",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.name",
      "path" : "CertDIVOC.evidence.facility.name",
      "short" : "Name of the facility/entity",
      "definition" : "Name of the facility/entity",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address",
      "path" : "CertDIVOC.evidence.facility.address",
      "short" : "Address of the facility",
      "definition" : "Address of the facility",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Address"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.streetAddress",
      "path" : "CertDIVOC.evidence.facility.address.streetAddress",
      "short" : "Line 1 of the address",
      "definition" : "Line 1 of the address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.streetAddress2",
      "path" : "CertDIVOC.evidence.facility.address.streetAddress2",
      "short" : "Line 2 of the address",
      "definition" : "Line 2 of the address",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.district",
      "path" : "CertDIVOC.evidence.facility.address.district",
      "short" : "District name (aka county)",
      "definition" : "District name (aka county)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.city",
      "path" : "CertDIVOC.evidence.facility.address.city",
      "short" : "Name of city, town etc.",
      "definition" : "Name of city, town etc.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.addressRegion",
      "path" : "CertDIVOC.evidence.facility.address.addressRegion",
      "short" : "Sub-unit of country (abbreviations ok)",
      "definition" : "Sub-unit of country (abbreviations ok)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.addressCountry",
      "path" : "CertDIVOC.evidence.facility.address.addressCountry",
      "short" : "Country (e.g. may be ISO 3166 2 or 3 letter code)",
      "definition" : "Country (e.g. may be ISO 3166 2 or 3 letter code)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.org/fhir/ValueSet/iso3166-1-3"
      }
    },
    {
      "id" : "CertDIVOC.evidence.facility.address.postalCode",
      "path" : "CertDIVOC.evidence.facility.address.postalCode",
      "short" : "Postal code for area",
      "definition" : "Postal code for area",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.icd11Code",
      "path" : "CertDIVOC.evidence.icd11Code",
      "short" : "ICD-11 code of this vaccine type (no binding information in spec)",
      "definition" : "The specification for DIVOC does not provide any information beyond that this is an ICD-11 code, so correspondingly there is no required binding to a specific ValueSet in this logical model.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://smart.who.int/ddcc/ValueSet/WHODDCCVaccinesCOVID19"
      }
    },
    {
      "id" : "CertDIVOC.evidence.prophylaxis",
      "path" : "CertDIVOC.evidence.prophylaxis",
      "short" : "Descriptive details of the vaccine type",
      "definition" : "Descriptive details of the vaccine type",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.testName",
      "path" : "CertDIVOC.evidence.testName",
      "short" : "Lab test results: Test name",
      "definition" : "Lab test results: Test name",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.testType",
      "path" : "CertDIVOC.evidence.testType",
      "short" : "Lab test results: Type of test, either `RT-PCR` or `Rapid Antigen Test (RAT)`",
      "definition" : "Lab test results: Type of test, either `RT-PCR` or `Rapid Antigen Test (RAT)`",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://smart.who.int/ddcc/ValueSet/LabTestTypeDivocValueSet"
      }
    },
    {
      "id" : "CertDIVOC.evidence.sampleOrigin",
      "path" : "CertDIVOC.evidence.sampleOrigin",
      "short" : "Lab test results: Type of sample that was taken (e.g., `nasal swab`",
      "definition" : "Lab test results: Type of sample that was taken (e.g., `nasal swab`",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://smart.who.int/ddcc/ValueSet/lab-test-sample-origin-divoc"
      }
    },
    {
      "id" : "CertDIVOC.evidence.disease",
      "path" : "CertDIVOC.evidence.disease",
      "short" : "Lab test results: Disease or agent targeted",
      "definition" : "Lab test results: Disease or agent targeted",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://smart.who.int/ddcc/ValueSet/LabTestPathogenDivocValueSet"
      }
    },
    {
      "id" : "CertDIVOC.evidence.sampleCollectionTimestamp",
      "path" : "CertDIVOC.evidence.sampleCollectionTimestamp",
      "short" : "Lab test results: Sample collection date and time; complete date, with time and time zone, following ISO 8601",
      "definition" : "Lab test results: Sample collection date and time; complete date, with time and time zone, following ISO 8601",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.resultTimestamp",
      "path" : "CertDIVOC.evidence.resultTimestamp",
      "short" : "Lab test results: Results date and time; complete date, with time and time zone, following ISO 8601",
      "definition" : "Lab test results: Results date and time; complete date, with time and time zone, following ISO 8601",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "CertDIVOC.evidence.result",
      "path" : "CertDIVOC.evidence.result",
      "short" : "Lab test results: result of test",
      "definition" : "Lab test results: result of test",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://smart.who.int/ddcc/ValueSet/LabTestQualitativeResultDivocValueSet"
      }
    },
    {
      "id" : "CertDIVOC.proof",
      "path" : "CertDIVOC.proof",
      "short" : "Proof",
      "definition" : "One or more cryptographic proofs that can be used to detect tampering and verify the authorship of a credential or presentation",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "CertDIVOC.proof.type",
      "path" : "CertDIVOC.proof.type",
      "short" : "Type of proof",
      "definition" : "Type of proof",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.proof.created",
      "path" : "CertDIVOC.proof.created",
      "short" : "Signature date and time",
      "definition" : "Signature date and time",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "CertDIVOC.proof.verificationMethod",
      "path" : "CertDIVOC.proof.verificationMethod",
      "short" : "Resolvable issuer identifier",
      "definition" : "Resolvable issuer identifier",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.proof.proofPurpose",
      "path" : "CertDIVOC.proof.proofPurpose",
      "short" : "Purpose of the signature",
      "definition" : "Clearly expresses the purpose for the proof and ensures this information is protected by the signature",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "CertDIVOC.proof.jws",
      "path" : "CertDIVOC.proof.jws",
      "short" : "Signature",
      "definition" : "Signature",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
