# Example-Russian - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-Russian**

## Example Bundle: Example-Russian



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Example-Russian",
  "meta" : {
    "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCVSDocument"]
  },
  "identifier" : {
    "system" : "urn:EXAMPLE-who-:ddcc:bundle:ids",
    "value" : "9990123012301230123"
  },
  "type" : "document",
  "timestamp" : "2021-06-03T13:28:17-05:00",
  "link" : [{
    "relation" : "publication",
    "url" : "urn:HCID:1234567890"
  }],
  "entry" : [{
    "fullUrl" : "http://www.example.org/fhir/Composition/DDCCCompositionExampleRussian",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "DDCCCompositionExampleRussian",
      "meta" : {
        "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCVSComposition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_DDCCCompositionExampleRussian\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition DDCCCompositionExampleRussian</b></p><a name=\"DDCCCompositionExampleRussian\"> </a><a name=\"hcDDCCCompositionExampleRussian\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DDCCVSComposition.html\">DDCC:VS Composition</a></p></div><p><b>identifier</b>: <code>urn:EXAMPLE-who-:ddcc:composition:ids</code>/999123456123456123456 (use: official, )</p><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 82593-5}\">Immunization summary report</span></p><p><b>date</b>: 2020-05-06</p><p><b>author</b>: <a href=\"Organization-DDCCOrganizationRussian.html\">Organization Государственная больница</a></p><p><b>title</b>: Digital Documentation of COVID-19 Certificate (DDCC)</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Official</td><td><a href=\"Organization-DDCCOrganizationRussian.html\">Organization Государственная больница</a></td></tr></table></div>"
      },
      "identifier" : {
        "use" : "official",
        "system" : "urn:EXAMPLE-who-:ddcc:composition:ids",
        "value" : "999123456123456123456"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "82593-5"
        }]
      },
      "subject" : {
        "reference" : "Patient/DDCCPatientRussian"
      },
      "date" : "2020-05-06",
      "author" : [{
        "reference" : "Organization/DDCCOrganizationRussian"
      }],
      "title" : "Digital Documentation of COVID-19 Certificate (DDCC)",
      "attester" : [{
        "mode" : "official",
        "party" : {
          "reference" : "Organization/DDCCOrganizationRussian"
        }
      }],
      "section" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6"
          }]
        },
        "focus" : {
          "reference" : "Immunization/DDCCImmunizationRussian"
        },
        "entry" : [{
          "reference" : "Immunization/DDCCImmunizationRussian"
        },
        {
          "reference" : "ImmunizationRecommendation/DDCCImmunizationRecommendationRussian"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://www.example.org/fhir/Patient/DDCCPatientRussian",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "DDCCPatientRussian",
      "meta" : {
        "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCPatient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_DDCCPatientRussian\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient DDCCPatientRussian</b></p><a name=\"DDCCPatientRussian\"> </a><a name=\"hcDDCCPatientRussian\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DDCCPatient.html\">DDCC Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Авл Агерий(official) (no stated gender), DoB: 2003-03-03</p><hr/></div>"
      },
      "name" : [{
        "use" : "official",
        "text" : "Авл Агерий"
      }],
      "birthDate" : "2003-03-03"
    }
  },
  {
    "fullUrl" : "http://www.example.org/fhir/Organization/DDCCOrganizationRussian",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "DDCCOrganizationRussian",
      "meta" : {
        "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCOrganization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_DDCCOrganizationRussian\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization DDCCOrganizationRussian</b></p><a name=\"DDCCOrganizationRussian\"> </a><a name=\"hcDDCCOrganizationRussian\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DDCCOrganization.html\">DDCC Organization</a></p></div><p><b>name</b>: Государственная больница</p></div>"
      },
      "name" : "Государственная больница"
    }
  },
  {
    "fullUrl" : "http://www.example.org/fhir/Immunization/DDCCImmunizationRussian",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "DDCCImmunizationRussian",
      "meta" : {
        "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCImmunization"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_DDCCImmunizationRussian\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization DDCCImmunizationRussian</b></p><a name=\"DDCCImmunizationRussian\"> </a><a name=\"hcDDCCImmunizationRussian\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DDCCImmunization.html\">DDCC Immunization</a></p></div><p><b>DDCC Event Brand for Immunization</b>: mms: XM5QM6 (XM5QM6)</p><p><b>DDCC Country Of Event for Immunization</b>: RUS</p><p><b>DDCC Vaccine Market Authorization for Immunization</b>: <a href=\"CodeSystem-DDCCExampleTestCodeSystem.html#DDCCExampleTestCodeSystem-TEST\">DDCC Codes for examples: TEST</a> (Test)</p><p><b>DDCC Vaccine Valid From</b>: 2021-05-30</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://id.who.int/icd11/mms XM9QW8}\">XM9QW8</span></p><p><b>patient</b>: <a href=\"Patient-DDCCPatientRussian.html\">Авл Агерий(official) (no stated gender), DoB: 2003-03-03</a></p><p><b>occurrence</b>: 2021-05-06</p><p><b>location</b>: Сайт вакцинации</p><p><b>lotNumber</b>: 123</p><p><b>expirationDate</b>: 2021-06-30</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-DDCCOrganizationRussian.html\">Organization Государственная больница</a></td></tr></table><h3>ProtocolApplieds</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Authority</b></td><td><b>TargetDisease</b></td><td><b>DoseNumber[x]</b></td><td><b>SeriesDoses[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-DDCCOrganizationRussian.html\">Organization Государственная больница</a></td><td><span title=\"Codes:{http://id.who.int/icd11/mms RA01}\">RA01</span></td><td>1</td><td>2</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://smart.who.int/ddcc/StructureDefinition/DDCCEventBrand",
        "valueCoding" : {
          "system" : "http://id.who.int/icd11/mms",
          "code" : "XM5QM6"
        }
      },
      {
        "url" : "http://smart.who.int/ddcc/StructureDefinition/DDCCCountryOfEvent",
        "valueCode" : "RUS"
      },
      {
        "url" : "http://smart.who.int/ddcc/StructureDefinition/DDCCVaccineMarketAuthorization",
        "valueCoding" : {
          "system" : "http://smart.who.int/ddcc/CodeSystem/DDCCExampleTestCodeSystem",
          "code" : "TEST"
        }
      },
      {
        "url" : "http://smart.who.int/ddcc/StructureDefinition/DDCCVaccineValidFrom",
        "valueDate" : "2021-05-30"
      }],
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://id.who.int/icd11/mms",
          "code" : "XM9QW8"
        }]
      },
      "patient" : {
        "reference" : "Patient/DDCCPatientRussian"
      },
      "occurrenceDateTime" : "2021-05-06",
      "location" : {
        "display" : "Сайт вакцинации"
      },
      "lotNumber" : "123",
      "expirationDate" : "2021-06-30",
      "performer" : [{
        "actor" : {
          "reference" : "Organization/DDCCOrganizationRussian"
        }
      }],
      "protocolApplied" : [{
        "authority" : {
          "reference" : "Organization/DDCCOrganizationRussian"
        },
        "targetDisease" : [{
          "coding" : [{
            "system" : "http://id.who.int/icd11/mms",
            "code" : "RA01"
          }]
        }],
        "doseNumberPositiveInt" : 1,
        "seriesDosesPositiveInt" : 2
      }]
    }
  },
  {
    "fullUrl" : "http://www.example.org/fhir/ImmunizationRecommendation/DDCCImmunizationRecommendationRussian",
    "resource" : {
      "resourceType" : "ImmunizationRecommendation",
      "id" : "DDCCImmunizationRecommendationRussian",
      "meta" : {
        "profile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCImmunizationRecommendation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImmunizationRecommendation_DDCCImmunizationRecommendationRussian\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImmunizationRecommendation DDCCImmunizationRecommendationRussian</b></p><a name=\"DDCCImmunizationRecommendationRussian\"> </a><a name=\"hcDDCCImmunizationRecommendationRussian\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DDCCImmunizationRecommendation.html\">DDCC Immunization Recommendation</a></p></div><p><b>patient</b>: <a href=\"Patient-DDCCPatientRussian.html\">Авл Агерий(official) (no stated gender), DoB: 2003-03-03</a></p><p><b>date</b>: 2021-05-06</p><blockquote><p><b>recommendation</b></p><p><b>vaccineCode</b>: <span title=\"Codes:{http://id.who.int/icd11/mms XM9QW8}\">XM9QW8</span></p><p><b>forecastStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/immunization-recommendation-status due}\">Due</span></p><h3>DateCriterions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 30980-7}\">Date vaccine due</span></td><td>2021-05-20</td></tr></table><p><b>supportingImmunization</b>: <a href=\"Immunization-DDCCImmunizationRussian.html\">Immunization: extension = XM5QM6 (mms#XM5QM6),RUS,Test (DDCC Codes for examples#TEST),2021-05-30; status = completed; vaccineCode = XM9QW8; occurrence[x] = 2021-05-06; lotNumber = 123; expirationDate = 2021-06-30</a></p></blockquote></div>"
      },
      "patient" : {
        "reference" : "Patient/DDCCPatientRussian"
      },
      "date" : "2021-05-06",
      "recommendation" : [{
        "vaccineCode" : [{
          "coding" : [{
            "system" : "http://id.who.int/icd11/mms",
            "code" : "XM9QW8"
          }]
        }],
        "forecastStatus" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/immunization-recommendation-status",
            "code" : "due"
          }]
        },
        "dateCriterion" : [{
          "code" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "30980-7"
            }]
          },
          "value" : "2021-05-20"
        }],
        "supportingImmunization" : [{
          "reference" : "Immunization/DDCCImmunizationRussian"
        }]
      }]
    }
  }]
}

```
