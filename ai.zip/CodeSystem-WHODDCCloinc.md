# LOINC codes used in this IG - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LOINC codes used in this IG**

## CodeSystem: LOINC codes used in this IG (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://loinc.org | *Version*:1.0.0 |
| Draft as of 2026-09-05 | *Computable Name*:WHODDCCloinc |

 
All LOINC codes from `http://loinc.org` used in this IG. Provided so the FHIR server can perform expansions. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Lab Test - Type - COVID-19 - LOINC](ValueSet-LabTestTypeCovid19LoincValueSet.md)
* [Lab Test - Type - Generic - LOINC](ValueSet-LabTestTypeLoincValueSet.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "WHODDCCloinc",
  "url" : "http://loinc.org",
  "version" : "1.0.0",
  "name" : "WHODDCCloinc",
  "title" : "LOINC codes used in this IG",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-09-05T20:45:54+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "All LOINC codes from `http://loinc.org` used in this IG. Provided so the FHIR server can perform expansions.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 165,
  "concept" : [{
    "code" : "LP6464-4",
    "display" : "Nucliec acid amplification with probe detection"
  },
  {
    "code" : "LP217198-3",
    "display" : "Rapid immunoassay"
  },
  {
    "code" : "100861-4",
    "display" : "Cells.CD4+CD154+/CD4 cells in Blood --after stimulation with SARS-CoV-2 Nucleocapsid peptide"
  },
  {
    "code" : "100858-0",
    "display" : "Cells.CD4+CD154+/CD4 cells in Blood --after stimulation with SARS-CoV-2 Spike peptide"
  },
  {
    "code" : "100862-2",
    "display" : "Cells.CD4.Interferon gamma-expressing/CD4 cells in Blood --after stimulation with SARS-CoV-2 Nucleocapsid peptide"
  },
  {
    "code" : "100859-8",
    "display" : "Cells.CD4.Interferon gamma-expressing/CD4 cells in Blood --after stimulation with SARS-CoV-2 Spike peptide"
  },
  {
    "code" : "100863-0",
    "display" : "Cells.CD4.Tumor necrosis factor alfa-expressing/CD4 cells in Blood --after stimulation with SARS-CoV-2 Nucleocapsid peptide"
  },
  {
    "code" : "100860-6",
    "display" : "Cells.CD4.Tumor necrosis factor alfa-expressing/CD4 cells in Blood --after stimulation with SARS-CoV-2 Spike peptide"
  },
  {
    "code" : "96766-1",
    "display" : "GISAID sequence accession number"
  },
  {
    "code" : "95942-9",
    "display" : "Influenza virus A and B and SARS-CoV+SARS-CoV-2 (COVID-19) Ag panel - Upper respiratory specimen by Rapid immunoassay"
  },
  {
    "code" : "97099-6",
    "display" : "Influenza virus A and B and SARS-CoV-2 (COVID-19) Ag panel - Upper respiratory specimen by Rapid immunoassay"
  },
  {
    "code" : "95941-1",
    "display" : "Influenza virus A and B and SARS-CoV-2 (COVID-19) and Respiratory syncytial virus RNA panel - Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95380-2",
    "display" : "Influenza virus A and B and SARS-CoV-2 (COVID-19) and SARS-related CoV RNA panel - Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95423-0",
    "display" : "Influenza virus A and B and SARS-CoV-2 (COVID-19) identified in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95422-2",
    "display" : "Influenza virus A and B and SARS-CoV-2 (COVID-19) RNA panel - Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "100345-8",
    "display" : "Influenza virus A and B and SARS-CoV-2 (COVID-19) RNA panel - Specimen by NAA with probe detection"
  },
  {
    "code" : "98733-9",
    "display" : "Percent neutralization by SARS coronavirus 2 spike protein RBD neutralizing antibody in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "99771-8",
    "display" : "SARS coronavirus 2 spike and nucleocapsid protein stimulated gamma interferon panel - Blood"
  },
  {
    "code" : "98846-9",
    "display" : "SARS coronavirus 2 stimulated gamma interferon release by Helper (CD4+) T-cells [Units/volume] corrected for background in Blood by Immunoassay"
  },
  {
    "code" : "98847-7",
    "display" : "SARS coronavirus 2 stimulated gamma interferon release by lymphocytes [Units/volume] corrected for background in Blood by Immunoassay"
  },
  {
    "code" : "99774-2",
    "display" : "SARS coronavirus 2 stimulated gamma interferon release by T-cells.Nucleocapsid Ag spot count [#] corrected for background in Blood"
  },
  {
    "code" : "99773-4",
    "display" : "SARS coronavirus 2 stimulated gamma interferon release by T-cells.Spike Ag spot count [#] corrected for background in Blood"
  },
  {
    "code" : "95209-3",
    "display" : "SARS-CoV+SARS-CoV-2 (COVID-19) Ag [Presence] in Respiratory specimen by Rapid immunoassay"
  },
  {
    "code" : "94763-0",
    "display" : "SARS-CoV-2 (COVID-19) [Presence] in Specimen by Organism specific culture"
  },
  {
    "code" : "94661-6",
    "display" : "SARS-CoV-2 (COVID-19) Ab [Interpretation] in Serum or Plasma"
  },
  {
    "code" : "95825-6",
    "display" : "SARS-CoV-2 (COVID-19) Ab [Presence] in DBS by Immunoassay"
  },
  {
    "code" : "98069-8",
    "display" : "SARS-CoV-2 (COVID-19) Ab [Presence] in Saliva (oral fluid) by Rapid immunoassay"
  },
  {
    "code" : "94762-2",
    "display" : "SARS-CoV-2 (COVID-19) Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "95542-7",
    "display" : "SARS-CoV-2 (COVID-19) Ab [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
  },
  {
    "code" : "94769-7",
    "display" : "SARS-CoV-2 (COVID-19) Ab [Units/volume] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "96118-5",
    "display" : "SARS-CoV-2 (COVID-19) Ab panel - DBS by Immunoassay"
  },
  {
    "code" : "94504-8",
    "display" : "SARS-CoV-2 (COVID-19) Ab panel - Serum or Plasma by Immunoassay"
  },
  {
    "code" : "94503-0",
    "display" : "SARS-CoV-2 (COVID-19) Ab panel - Serum, Plasma or Blood by Rapid immunoassay"
  },
  {
    "code" : "94558-4",
    "display" : "SARS-CoV-2 (COVID-19) Ag [Presence] in Respiratory specimen by Rapid immunoassay"
  },
  {
    "code" : "96119-3",
    "display" : "SARS-CoV-2 (COVID-19) Ag [Presence] in Upper respiratory specimen by Immunoassay"
  },
  {
    "code" : "97097-0",
    "display" : "SARS-CoV-2 (COVID-19) Ag [Presence] in Upper respiratory specimen by Rapid immunoassay"
  },
  {
    "code" : "96094-8",
    "display" : "SARS-CoV-2 (COVID-19) and SARS-related CoV RNA panel - Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "98080-5",
    "display" : "SARS-CoV-2 (COVID-19) and SARS-related CoV RNA panel - Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "96896-6",
    "display" : "SARS-CoV-2 (COVID-19) clade [Type] in Specimen by Molecular genetics method"
  },
  {
    "code" : "96764-6",
    "display" : "SARS-CoV-2 (COVID-19) E gene [Cycle Threshold #] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "96763-8",
    "display" : "SARS-CoV-2 (COVID-19) E gene [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94562-6",
    "display" : "SARS-CoV-2 (COVID-19) IgA Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "94768-9",
    "display" : "SARS-CoV-2 (COVID-19) IgA Ab [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
  },
  {
    "code" : "95427-1",
    "display" : "SARS-CoV-2 (COVID-19) IgA Ab [Titer] in Serum or Plasma by Immunofluorescence"
  },
  {
    "code" : "94720-0",
    "display" : "SARS-CoV-2 (COVID-19) IgA Ab [Units/volume] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "95125-1",
    "display" : "SARS-CoV-2 (COVID-19) IgA+IgM [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "96742-2",
    "display" : "SARS-CoV-2 (COVID-19) IgG Ab [Mass/volume] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "94761-4",
    "display" : "SARS-CoV-2 (COVID-19) IgG Ab [Presence] in DBS by Immunoassay"
  },
  {
    "code" : "94563-4",
    "display" : "SARS-CoV-2 (COVID-19) IgG Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "94507-1",
    "display" : "SARS-CoV-2 (COVID-19) IgG Ab [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
  },
  {
    "code" : "95429-7",
    "display" : "SARS-CoV-2 (COVID-19) IgG Ab [Titer] in Serum or Plasma by Immunofluorescence"
  },
  {
    "code" : "94505-5",
    "display" : "SARS-CoV-2 (COVID-19) IgG Ab [Units/volume] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "94547-7",
    "display" : "SARS-CoV-2 (COVID-19) IgG+IgM Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "95416-4",
    "display" : "SARS-CoV-2 (COVID-19) IgM Ab [Presence] in DBS by Immunoassay"
  },
  {
    "code" : "94564-2",
    "display" : "SARS-CoV-2 (COVID-19) IgM Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "94508-9",
    "display" : "SARS-CoV-2 (COVID-19) IgM Ab [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
  },
  {
    "code" : "95428-9",
    "display" : "SARS-CoV-2 (COVID-19) IgM Ab [Titer] in Serum or Plasma by Immunofluorescence"
  },
  {
    "code" : "94506-3",
    "display" : "SARS-CoV-2 (COVID-19) IgM Ab [Units/volume] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "96895-8",
    "display" : "SARS-CoV-2 (COVID-19) lineage [Identifier] in Specimen by Molecular genetics method"
  },
  {
    "code" : "100157-7",
    "display" : "SARS-CoV-2 (COVID-19) lineage [Type] in Specimen by Sequencing"
  },
  {
    "code" : "96957-6",
    "display" : "SARS-CoV-2 (COVID-19) M gene [Presence] in Upper respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95521-1",
    "display" : "SARS-CoV-2 (COVID-19) N gene [#/volume] (viral load) in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "96898-2",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Cycle Threshold #] in Oropharyngeal wash by NAA with probe detection"
  },
  {
    "code" : "94510-5",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Cycle Threshold #] in Specimen by NAA with probe detection"
  },
  {
    "code" : "94311-8",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Cycle Threshold #] in Specimen by Nucleic acid amplification using CDC primer-probe set N1"
  },
  {
    "code" : "94312-6",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Cycle Threshold #] in Specimen by Nucleic acid amplification using CDC primer-probe set N2"
  },
  {
    "code" : "95522-9",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Log #/volume] (viral load) in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94760-6",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Nasopharynx by NAA with probe detection"
  },
  {
    "code" : "96986-5",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Nose by NAA with non-probe detection"
  },
  {
    "code" : "95409-9",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Nose by NAA with probe detection"
  },
  {
    "code" : "94533-7",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94756-4",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Respiratory specimen by Nucleic acid amplification using CDC primer-probe set N1"
  },
  {
    "code" : "94757-2",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Respiratory specimen by Nucleic acid amplification using CDC primer-probe set N2"
  },
  {
    "code" : "95425-5",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "96448-6",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Saliva (oral fluid) by Nucleic acid amplification using CDC primer-probe set N1"
  },
  {
    "code" : "96958-4",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Saliva (oral fluid) by Nucleic acid amplification using CDC primer-probe set N2"
  },
  {
    "code" : "94766-3",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Serum or Plasma by NAA with probe detection"
  },
  {
    "code" : "94316-7",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "94307-6",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Specimen by Nucleic acid amplification using CDC primer-probe set N1"
  },
  {
    "code" : "94308-4",
    "display" : "SARS-CoV-2 (COVID-19) N gene [Presence] in Specimen by Nucleic acid amplification using CDC primer-probe set N2"
  },
  {
    "code" : "99596-9",
    "display" : "SARS-CoV-2 (COVID-19) N protein IgG Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "95411-5",
    "display" : "SARS-CoV-2 (COVID-19) neutralizing antibody [Presence] in Serum by pVNT"
  },
  {
    "code" : "95410-7",
    "display" : "SARS-CoV-2 (COVID-19) neutralizing antibody [Titer] in Serum by pVNT"
  },
  {
    "code" : "97098-8",
    "display" : "SARS-CoV-2 (COVID-19) Nsp2 gene [Presence] in Upper respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "98132-4",
    "display" : "SARS-CoV-2 (COVID-19) ORF1a region [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "98494-8",
    "display" : "SARS-CoV-2 (COVID-19) ORF1a region [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "96899-0",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Cycle Threshold #] in Oropharyngeal wash by NAA with probe detection"
  },
  {
    "code" : "94644-2",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Cycle Threshold #] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94511-3",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Cycle Threshold #] in Specimen by NAA with probe detection"
  },
  {
    "code" : "94559-2",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95824-9",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94639-2",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "97104-4",
    "display" : "SARS-CoV-2 (COVID-19) ORF1ab region [Units/volume] (viral load) in Upper respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "98131-6",
    "display" : "SARS-CoV-2 (COVID-19) ORF1b region [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "98493-0",
    "display" : "SARS-CoV-2 (COVID-19) ORF1b region [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94646-7",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Cycle Threshold #] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94645-9",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Cycle Threshold #] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96120-1",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Presence] in Lower respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94534-5",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "96091-4",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94314-2",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96123-5",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene [Presence] in Upper respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "99314-7",
    "display" : "SARS-CoV-2 (COVID-19) RdRp gene mutation detected [Identifier] in Specimen by Molecular genetics method"
  },
  {
    "code" : "94745-7",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Cycle Threshold #] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94746-5",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Cycle Threshold #] in Specimen by NAA with probe detection"
  },
  {
    "code" : "94819-0",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Log #/volume] (viral load) in Specimen by NAA with probe detection"
  },
  {
    "code" : "94565-9",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Nasopharynx by NAA with non-probe detection"
  },
  {
    "code" : "94759-8",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Nasopharynx by NAA with probe detection"
  },
  {
    "code" : "95406-5",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Nose by NAA with probe detection"
  },
  {
    "code" : "96797-6",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Oropharyngeal wash by NAA with probe detection"
  },
  {
    "code" : "95608-6",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Respiratory specimen by NAA with non-probe detection"
  },
  {
    "code" : "94500-6",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95424-8",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Respiratory specimen by Sequencing"
  },
  {
    "code" : "94845-5",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94822-4",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Saliva (oral fluid) by Sequencing"
  },
  {
    "code" : "94660-8",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Serum or Plasma by NAA with probe detection"
  },
  {
    "code" : "94309-2",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96829-7",
    "display" : "SARS-CoV-2 (COVID-19) RNA [Presence] in Specimen from Donor by NAA with probe detection"
  },
  {
    "code" : "96897-4",
    "display" : "SARS-CoV-2 (COVID-19) RNA panel - Oropharyngeal wash by NAA with probe detection"
  },
  {
    "code" : "94531-1",
    "display" : "SARS-CoV-2 (COVID-19) RNA panel - Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95826-4",
    "display" : "SARS-CoV-2 (COVID-19) RNA panel - Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94306-8",
    "display" : "SARS-CoV-2 (COVID-19) RNA panel - Specimen by NAA with probe detection"
  },
  {
    "code" : "96900-6",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Cycle Threshold #] in Oropharyngeal wash by NAA with probe detection"
  },
  {
    "code" : "94642-6",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Cycle Threshold #] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94643-4",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Cycle Threshold #] in Specimen by NAA with probe detection"
  },
  {
    "code" : "94640-0",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95609-4",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Presence] in Respiratory specimen by Sequencing"
  },
  {
    "code" : "96765-3",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94767-1",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Presence] in Serum or Plasma by NAA with probe detection"
  },
  {
    "code" : "94641-8",
    "display" : "SARS-CoV-2 (COVID-19) S gene [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96752-1",
    "display" : "SARS-CoV-2 (COVID-19) S gene mutation [Presence] in Specimen by Molecular genetics method"
  },
  {
    "code" : "96751-3",
    "display" : "SARS-CoV-2 (COVID-19) S gene mutation detected [Identifier] in Specimen by Molecular genetics method"
  },
  {
    "code" : "99597-7",
    "display" : "SARS-CoV-2 (COVID-19) S protein IgG Ab [Presence] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "96603-6",
    "display" : "SARS-CoV-2 (COVID-19) S protein RBD neutralizing antibody [Presence] in Serum or Plasma by sVNT"
  },
  {
    "code" : "98732-1",
    "display" : "SARS-CoV-2 (COVID-19) S protein RBD neutralizing antibody [Titer] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "98734-7",
    "display" : "SARS-CoV-2 (COVID-19) S protein RBD neutralizing antibody [Units/volume] in Serum or Plasma by Immunoassay"
  },
  {
    "code" : "96894-1",
    "display" : "SARS-CoV-2 (COVID-19) sequencing and identification panel - Specimen by Molecular genetics method"
  },
  {
    "code" : "95970-0",
    "display" : "SARS-CoV-2 (COVID-19) specific TCRB gene rearrangements [Presence] in Blood by Sequencing"
  },
  {
    "code" : "100156-9",
    "display" : "SARS-CoV-2 (COVID-19) variant [Type] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96741-4",
    "display" : "SARS-CoV-2 (COVID-19) variant [Type] in Specimen by Sequencing"
  },
  {
    "code" : "96755-4",
    "display" : "SARS-CoV-2 (COVID-19) variant interpretation in Specimen Narrative"
  },
  {
    "code" : "94764-8",
    "display" : "SARS-CoV-2 (COVID-19) whole genome [Nucleotide sequence] in Isolate or Specimen by Sequencing"
  },
  {
    "code" : "99772-6",
    "display" : "SARS-CoV-2 stimulated gamma interferon [Interpretation] in Blood Qualitative"
  },
  {
    "code" : "95971-8",
    "display" : "SARS-CoV-2 stimulated gamma interferon [Presence] in Blood"
  },
  {
    "code" : "95974-2",
    "display" : "SARS-CoV-2 stimulated gamma interferon panel - Blood"
  },
  {
    "code" : "95972-6",
    "display" : "SARS-CoV-2 stimulated gamma interferon release by T-cells [Units/volume] corrected for background in Blood"
  },
  {
    "code" : "95973-4",
    "display" : "SARS-CoV-2 stimulated gamma interferon release by T-cells [Units/volume] in Blood"
  },
  {
    "code" : "94509-7",
    "display" : "SARS-related coronavirus E gene [Cycle Threshold #] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96121-9",
    "display" : "SARS-related coronavirus E gene [Presence] in Lower respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94758-0",
    "display" : "SARS-related coronavirus E gene [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "95823-1",
    "display" : "SARS-related coronavirus E gene [Presence] in Saliva (oral fluid) by NAA with probe detection"
  },
  {
    "code" : "94765-5",
    "display" : "SARS-related coronavirus E gene [Presence] in Serum or Plasma by NAA with probe detection"
  },
  {
    "code" : "94315-9",
    "display" : "SARS-related coronavirus E gene [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "96122-7",
    "display" : "SARS-related coronavirus E gene [Presence] in Upper respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94313-4",
    "display" : "SARS-related coronavirus N gene [Cycle Threshold #] in Specimen by Nucleic acid amplification using CDC primer-probe set N3"
  },
  {
    "code" : "94310-0",
    "display" : "SARS-related coronavirus N gene [Presence] in Specimen by Nucleic acid amplification using CDC primer-probe set N3"
  },
  {
    "code" : "94502-2",
    "display" : "SARS-related coronavirus RNA [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "94647-5",
    "display" : "SARS-related coronavirus RNA [Presence] in Specimen by NAA with probe detection"
  },
  {
    "code" : "94532-9",
    "display" : "SARS-related coronavirus+MERS coronavirus RNA [Presence] in Respiratory specimen by NAA with probe detection"
  },
  {
    "code" : "98062-3",
    "display" : "Sequencing study identifier"
  },
  {
    "code" : "100342-5",
    "display" : "Volatile Organic Compounds associated with SARS-CoV-2 infection [Presence] in Exhaled gas by Gas chromatography-mass spectrometry"
  },
  {
    "code" : "82593-5",
    "display" : "Immunization summary report"
  },
  {
    "code" : "11369-6",
    "display" : "History of Immunization Narrative"
  },
  {
    "code" : "30954-2",
    "display" : "Relevant diagnostic tests/laboratory data Narrative"
  },
  {
    "code" : "30980-7",
    "display" : "Date vaccine due"
  }]
}

```
