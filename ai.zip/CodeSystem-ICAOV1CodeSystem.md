# DDCC Codes for ICAO Vaccines - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DDCC Codes for ICAO Vaccines**

## CodeSystem: DDCC Codes for ICAO Vaccines 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/CodeSystem/ICAOV1CodeSystem | *Version*:1.0.0 |
| Draft as of 2026-09-05 | *Computable Name*:ICAOV1CodeSystem |

 
ICAO vaccines codes for DDCC so the FHIR server can perform expansions. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [DDCC Codes for ICAO Vaccines](ValueSet-ICAOV1ValueSet.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ICAOV1CodeSystem",
  "url" : "http://smart.who.int/ddcc/CodeSystem/ICAOV1CodeSystem",
  "version" : "1.0.0",
  "name" : "ICAOV1CodeSystem",
  "title" : "DDCC Codes for ICAO Vaccines",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-09-05T20:45:54+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "ICAO vaccines codes for DDCC so the FHIR server can perform expansions.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 97,
  "concept" : [{
    "code" : "ICAO001",
    "display" : "Comirnaty"
  },
  {
    "code" : "ICAO002",
    "display" : "Tozinameran"
  },
  {
    "code" : "ICAO003",
    "display" : "Pfizer-BioNTech COVID-19 vaccine BNT162b2"
  },
  {
    "code" : "ICAO004",
    "display" : "3 LNP-mRNAS"
  },
  {
    "code" : "ICAO005",
    "display" : "Tozinameran (INN)"
  },
  {
    "code" : "ICAO006",
    "display" : "BNT162b2/COMIRNATY"
  },
  {
    "code" : "ICAO007",
    "display" : "Pfizer BioNTech-Comirnaty"
  },
  {
    "code" : "ICAO008",
    "display" : "BNT162"
  },
  {
    "code" : "ICAO009",
    "display" : "COVID-19 Vaccine Moderna"
  },
  {
    "code" : "ICAO010",
    "display" : "COVID-19 mRNA Vaccine Moderna mRNA-1273"
  },
  {
    "code" : "ICAO011",
    "display" : "Spikevax"
  },
  {
    "code" : "ICAO012",
    "display" : "Moderna-Spikevax"
  },
  {
    "code" : "ICAO013",
    "display" : "ZyCov-D"
  },
  {
    "code" : "ICAO014",
    "display" : "Zydus-ZyCov-D"
  },
  {
    "code" : "ICAO015",
    "display" : "Recombinant SARS-CoV-2 vaccine"
  },
  {
    "code" : "ICAO016",
    "display" : "Anhui ZL - Recombinant"
  },
  {
    "code" : "ICAO017",
    "display" : "Adjuvanted recombinant protein (RBD-DIMER)"
  },
  {
    "code" : "ICAO018",
    "display" : "ZF2001"
  },
  {
    "code" : "ICAO019",
    "display" : "ZF-UZ-VAC 2001"
  },
  {
    "code" : "ICAO020",
    "display" : "Soberana-02"
  },
  {
    "code" : "ICAO021",
    "display" : "Finlay - Soberana-02"
  },
  {
    "code" : "ICAO022",
    "display" : "RRBD produced in CHO-cell chemically conjugated to tetanus toxoid"
  },
  {
    "code" : "ICAO023",
    "display" : "FINLAY-FR2"
  },
  {
    "code" : "ICAO024",
    "display" : "PASTUCOVAC"
  },
  {
    "code" : "ICAO025",
    "display" : "MVC-COV1901"
  },
  {
    "code" : "ICAO026",
    "display" : "Medigen-MVC-COV1901"
  },
  {
    "code" : "ICAO027",
    "display" : "MVC COVID-19 vaccine"
  },
  {
    "code" : "ICAO028",
    "display" : "EpiVacCorona"
  },
  {
    "code" : "ICAO029",
    "display" : "SRCVB-EpiVacCorona"
  },
  {
    "code" : "ICAO030",
    "display" : "Soberana Plus"
  },
  {
    "code" : "ICAO031",
    "display" : "Finlay-Soberana Plus"
  },
  {
    "code" : "ICAO032",
    "display" : "EpiVacCorona-N"
  },
  {
    "code" : "ICAO033",
    "display" : "SRCVB-EpiVacCorona-N"
  },
  {
    "code" : "ICAO034",
    "display" : "SpikoGen"
  },
  {
    "code" : "ICAO035",
    "display" : "Vaxine-SpikoGen"
  },
  {
    "code" : "ICAO036",
    "display" : "COVAX-19"
  },
  {
    "code" : "ICAO037",
    "display" : "Novavax COVID-19 vaccine"
  },
  {
    "code" : "ICAO038",
    "display" : "Novavax-Covovax"
  },
  {
    "code" : "ICAO039",
    "display" : "Nuvaxovid"
  },
  {
    "code" : "ICAO040",
    "display" : "NVX-CoV2373"
  },
  {
    "code" : "ICAO041",
    "display" : "Covovax"
  },
  {
    "code" : "ICAO042",
    "display" : "Razi COV PARS"
  },
  {
    "code" : "ICAO043",
    "display" : "COVID-19 Vaccine AstraZeneca"
  },
  {
    "code" : "ICAO044",
    "display" : "Vaxzevria"
  },
  {
    "code" : "ICAO045",
    "display" : "COVID-19 Vaccine AstraZeneca AZD1222"
  },
  {
    "code" : "ICAO046",
    "display" : "COVID-19 Vaccine AstraZeneca ChAdOx1 nCoV-19"
  },
  {
    "code" : "ICAO047",
    "display" : "COVID-19 Vaccine AstraZeneca ChAdOx1-S"
  },
  {
    "code" : "ICAO048",
    "display" : "AstraZeneca-Vaxzevria"
  },
  {
    "code" : "ICAO049",
    "display" : "R-Covi"
  },
  {
    "code" : "ICAO050",
    "display" : "Covishield"
  },
  {
    "code" : "ICAO051",
    "display" : "Covishield AZD1222"
  },
  {
    "code" : "ICAO052",
    "display" : "Covishield ChAdOx1 nCoV-19"
  },
  {
    "code" : "ICAO053",
    "display" : "Covishield ChAdOx1-S"
  },
  {
    "code" : "ICAO054",
    "display" : "SII-Covishield"
  },
  {
    "code" : "ICAO055",
    "display" : "COVID-19 Vaccine Janssen"
  },
  {
    "code" : "ICAO056",
    "display" : "Ad26.COV 2.S"
  },
  {
    "code" : "ICAO057",
    "display" : "Johnson & Johnson COVID-19 vaccine"
  },
  {
    "code" : "ICAO058",
    "display" : "Janssen - Ad26.COV 2-S"
  },
  {
    "code" : "ICAO059",
    "display" : "Convidecia"
  },
  {
    "code" : "ICAO060",
    "display" : "CanSino-Convidecia"
  },
  {
    "code" : "ICAO061",
    "display" : "Ad5-nCOV"
  },
  {
    "code" : "ICAO062",
    "display" : "Gam-Covid-Vac"
  },
  {
    "code" : "ICAO063",
    "display" : "Gamaleya-Gam-Covid-Vac"
  },
  {
    "code" : "ICAO064",
    "display" : "Sputnik-V"
  },
  {
    "code" : "ICAO065",
    "display" : "Gam-KOVID-Vak"
  },
  {
    "code" : "ICAO066",
    "display" : "Sputnik-Light"
  },
  {
    "code" : "ICAO067",
    "display" : "Gamaleya-Sputnik-Light"
  },
  {
    "code" : "ICAO068",
    "display" : "CoronaVac"
  },
  {
    "code" : "ICAO069",
    "display" : "Sinovac COVID-19 Vaccine"
  },
  {
    "code" : "ICAO070",
    "display" : "PICOVACC"
  },
  {
    "code" : "ICAO071",
    "display" : "BBIBP-CorV"
  },
  {
    "code" : "ICAO072",
    "display" : "Sinopharm BBIBP-CorV"
  },
  {
    "code" : "ICAO073",
    "display" : "Sinopharm COVID-19 vaccine"
  },
  {
    "code" : "ICAO074",
    "display" : "Beijing CNBG - BBIBP-CorV"
  },
  {
    "code" : "ICAO075",
    "display" : "COVID-19 Vaccine BIBP"
  },
  {
    "code" : "ICAO076",
    "display" : "KCONVAC"
  },
  {
    "code" : "ICAO077",
    "display" : "Beijing Minhai-KCONVAC"
  },
  {
    "code" : "ICAO078",
    "display" : "Inactivated SARS-COV-2 vaccine, Vero cell"
  },
  {
    "code" : "ICAO079",
    "display" : "Covaxin"
  },
  {
    "code" : "ICAO080",
    "display" : "Bharat-Covaxin"
  },
  {
    "code" : "ICAO081",
    "display" : "BBV152"
  },
  {
    "code" : "ICAO082",
    "display" : "Covi-Vac"
  },
  {
    "code" : "ICAO083",
    "display" : "Chumakov-Covi-Vac"
  },
  {
    "code" : "ICAO084",
    "display" : "CoviVac"
  },
  {
    "code" : "ICAO085",
    "display" : "Hayat-Vax"
  },
  {
    "code" : "ICAO086",
    "display" : "Julphar-Hayat-Vax"
  },
  {
    "code" : "ICAO087",
    "display" : "QazVac"
  },
  {
    "code" : "ICAO088",
    "display" : "RIBSP-QazVac"
  },
  {
    "code" : "ICAO089",
    "display" : "QazCovid-in"
  },
  {
    "code" : "ICAO090",
    "display" : "COVIran Barakat"
  },
  {
    "code" : "ICAO091",
    "display" : "Shifa-COVIran Barakat"
  },
  {
    "code" : "ICAO092",
    "display" : "Covidful"
  },
  {
    "code" : "ICAO093",
    "display" : "IMB-inactivated"
  },
  {
    "code" : "ICAO094",
    "display" : "IMB-Covidful"
  },
  {
    "code" : "ICAO095",
    "display" : "Sinopharm WIBP-CorV"
  },
  {
    "code" : "ICAO096",
    "display" : "WIBP-CorV"
  },
  {
    "code" : "ICAO097",
    "display" : "Wuhan CNBG-Inactivated"
  }]
}

```
