# ConceptMap from ICAO to ICD-11 for Vaccines - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ConceptMap from ICAO to ICD-11 for Vaccines**

## ConceptMap: ConceptMap from ICAO to ICD-11 for Vaccines (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/ConceptMap/who-ddcc-map-icao-icd11-vaccines | *Version*:1.0.0 |
| Draft as of 2022-11-23 | *Computable Name*:ICAO_ICD11_COVID19_vaccines |

 
Rule-based mappings between ICAO and ICD-11 for COVID-19 Vaccines 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "who-ddcc-map-icao-icd11-vaccines",
  "url" : "http://smart.who.int/ddcc/ConceptMap/who-ddcc-map-icao-icd11-vaccines",
  "version" : "1.0.0",
  "name" : "ICAO_ICD11_COVID19_vaccines",
  "title" : "ConceptMap from ICAO to ICD-11 for Vaccines",
  "status" : "draft",
  "experimental" : true,
  "date" : "2022-11-23",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Rule-based mappings between ICAO and ICD-11 for COVID-19 Vaccines",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "group" : [{
    "source" : "http://id.who.int/icd11/mms",
    "target" : "http://smart.who.int/ddcc/ICAOV1",
    "element" : [{
      "code" : "ICAO001",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO002",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO003",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO004",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO005",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO006",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO007",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO008",
      "target" : [{
        "code" : "XM68M6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO009",
      "target" : [{
        "code" : "XM3DT5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO010",
      "target" : [{
        "code" : "XM3DT5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO011",
      "target" : [{
        "code" : "XM3DT5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO012",
      "target" : [{
        "code" : "XM3DT5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO013",
      "target" : [{
        "code" : "XM52P3",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO014",
      "target" : [{
        "code" : "XM52P3",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO015",
      "target" : [{
        "code" : "XM3CT4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO016",
      "target" : [{
        "code" : "XM3CT4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO017",
      "target" : [{
        "code" : "XM3CT4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO018",
      "target" : [{
        "code" : "XM3CT4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO019",
      "target" : [{
        "code" : "XM3CT4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO020",
      "target" : [{
        "code" : "XM3PG0",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO021",
      "target" : [{
        "code" : "XM3PG0",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO022",
      "target" : [{
        "code" : "XM3PG0",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO023",
      "target" : [{
        "code" : "XM3PG0",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO024",
      "target" : [{
        "code" : "XM3PG0",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO025",
      "target" : [{
        "code" : "XM4EC8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO026",
      "target" : [{
        "code" : "XM4EC8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO027",
      "target" : [{
        "code" : "XM4EC8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO028",
      "target" : [{
        "code" : "XM6SZ8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO029",
      "target" : [{
        "code" : "XM6SZ8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO030",
      "target" : [{
        "code" : "XM0RV9",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO031",
      "target" : [{
        "code" : "XM0RV9",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO032",
      "target" : [{
        "code" : "XM3SK8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO033",
      "target" : [{
        "code" : "XM3SK8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO034",
      "target" : [{
        "code" : "XM9P21",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO035",
      "target" : [{
        "code" : "XM9P21",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO036",
      "target" : [{
        "code" : "XM9P21",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO037",
      "target" : [{
        "code" : "XM9T65",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO038",
      "target" : [{
        "code" : "XM9T65",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO039",
      "target" : [{
        "code" : "XM9T65",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO040",
      "target" : [{
        "code" : "XM9T65",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO041",
      "target" : [{
        "code" : "XM9T65",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO042",
      "target" : [{
        "code" : "XM9N08",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO043",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO044",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO045",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO046",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO047",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO048",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO049",
      "target" : [{
        "code" : "XM4YL8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO050",
      "target" : [{
        "code" : "XM97T2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO051",
      "target" : [{
        "code" : "XM97T2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO052",
      "target" : [{
        "code" : "XM97T2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO053",
      "target" : [{
        "code" : "XM97T2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO054",
      "target" : [{
        "code" : "XM97T2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO055",
      "target" : [{
        "code" : "XM6QV1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO056",
      "target" : [{
        "code" : "XM6QV1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO057",
      "target" : [{
        "code" : "XM6QV1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO058",
      "target" : [{
        "code" : "XM6QV1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO059",
      "target" : [{
        "code" : "XM1AG7",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO060",
      "target" : [{
        "code" : "XM1AG7",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO061",
      "target" : [{
        "code" : "XM1AG7",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO062",
      "target" : [{
        "code" : "XM5ZJ4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO063",
      "target" : [{
        "code" : "XM5ZJ4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO064",
      "target" : [{
        "code" : "XM5ZJ4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO065",
      "target" : [{
        "code" : "XM5ZJ4",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO066",
      "target" : [{
        "code" : "XM5QM6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO067",
      "target" : [{
        "code" : "XM5QM6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO068",
      "target" : [{
        "code" : "XM7HT3",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO069",
      "target" : [{
        "code" : "XM7HT3",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO070",
      "target" : [{
        "code" : "XM7HT3",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO071",
      "target" : [{
        "code" : "XM8866",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO072",
      "target" : [{
        "code" : "XM8866",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO073",
      "target" : [{
        "code" : "XM8866",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO074",
      "target" : [{
        "code" : "XM8866",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO075",
      "target" : [{
        "code" : "XM8866",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO076",
      "target" : [{
        "code" : "XM9TQ1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO077",
      "target" : [{
        "code" : "XM9TQ1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO078",
      "target" : [{
        "code" : "XM9TQ1",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO079",
      "target" : [{
        "code" : "XM1G90",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO080",
      "target" : [{
        "code" : "XM1G90",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO081",
      "target" : [{
        "code" : "XM1G90",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO082",
      "target" : [{
        "code" : "XM85P5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO083",
      "target" : [{
        "code" : "XM85P5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO084",
      "target" : [{
        "code" : "XM85P5",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO085",
      "target" : [{
        "code" : "XM9FQ7",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO086",
      "target" : [{
        "code" : "XM9FQ7",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO087",
      "target" : [{
        "code" : "XM97N6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO088",
      "target" : [{
        "code" : "XM97N6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO089",
      "target" : [{
        "code" : "XM97N6",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO090",
      "target" : [{
        "code" : "XM2YG8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO091",
      "target" : [{
        "code" : "XM2YG8",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO092",
      "target" : [{
        "code" : "XM0K39",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO093",
      "target" : [{
        "code" : "XM0K39",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO094",
      "target" : [{
        "code" : "XM0K39",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO095",
      "target" : [{
        "code" : "XM1AU2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO096",
      "target" : [{
        "code" : "XM1AU2",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ICAO097",
      "target" : [{
        "code" : "XM1AU2",
        "equivalence" : "wider"
      }]
    }]
  }]
}

```
