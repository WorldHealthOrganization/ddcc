# SHCVaccinationBundleDM-Example-English-From-ddcc-to-shc - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SHCVaccinationBundleDM-Example-English-From-ddcc-to-shc**

## Bundle: SHCVaccinationBundleDM-Example-English-From-ddcc-to-shc



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "SHCVaccinationBundleDM-Example-English-From-ddcc-to-shc",
  "type" : "collection",
  "entry" : [{
    "fullUrl" : "resource:0",
    "resource" : {
      "resourceType" : "Patient",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_null\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient </b></p><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Aulus Agerius (no stated gender), DoB: 2003-03-03</p><hr/></div>"
      },
      "name" : [{
        "text" : "Aulus Agerius"
      }],
      "birthDate" : "2003-03-03"
    }
  },
  {
    "fullUrl" : "resource:1",
    "resource" : {
      "resourceType" : "Immunization",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_null\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization </b></p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:{http://id.who.int/icd11/mms XM0CX4}\">XM0CX4</span></p><p><b>patient</b>: <a href=\"Bundle-SHCVaccinationBundleDM-Example-English-From-ddcc-to-shc.html#resource-0\">Aulus Agerius (no stated gender), DoB: 2003-03-03</a></p><p><b>occurrence</b>: 2021-05-06</p><p><b>manufacturer</b>: Identifier: <code>http://smart.who.int/ddcc/CodeSystem/DDCCExampleTestCodeSystem</code>/TEST</p><p><b>lotNumber</b>: 123</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td>Government Hospital</td></tr></table></div>"
      },
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "system" : "http://id.who.int/icd11/mms",
          "code" : "XM0CX4"
        }]
      },
      "patient" : {
        "reference" : "resource:0"
      },
      "occurrenceDateTime" : "2021-05-06",
      "manufacturer" : {
        "identifier" : {
          "system" : "http://smart.who.int/ddcc/CodeSystem/DDCCExampleTestCodeSystem",
          "value" : "TEST"
        }
      },
      "lotNumber" : "123",
      "performer" : [{
        "actor" : {
          "display" : "Government Hospital"
        }
      }]
    }
  }]
}

```
