# Home - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/ImplementationGuide/who.ddcc | *Version*:1.0.0 |
| Draft as of 2022-03-22 | *Computable Name*:DDCC |

 This WHO Digital Documentation of COVID-19 Certificates (DDCC) Implementation Guide details how to use Health Level 7 (HL7) Fast Healthcare Interoperability Resources (FHIR) for consistent digital representation of COVID-19 certificates and interoperability. 

> This release of the implementation guide is based on the content at [https://github.com/WorldHealthOrganization/ddcc/tree/v1.0.0](https://github.com/WorldHealthOrganization/ddcc/tree/v1.0.0)**This implementation guide is undergoing continuous development and implementers should consider the following:**
* The package name `who.int` is maintained for compatibility but is expected to change for future releases.
* Some artifacts will change their names to follow a consistent naming convention.
* There are known issues in some artifacts.

### Summary

 This implementation guide contains a standards-compliant specifications for the DDCC: Vaccination Status and Test Result technical specifications and guidance documents. It explicitly encodes computer-interoperable logic, including data models, terminologies, and logic expressions, in a computable language to support implementation of vaccination and test result use cases by Member States. 

 To facilitate implementation of effective and interoperable digital solutions: 
* The [DDCC: Vaccination Status (DDCC:VS) technical specifications and implementation guidance ](https://www.who.int/publications/i/item/WHO-2019-nCoV-Digital_certificates-vaccination-2021.1)was issued for vaccination certificates for the purposes of continuity of care and proof of vaccination.
* The [DDCC: Test Result (DDCC:TR) technical specifications and implementation guidance](https://www.who.int/publications/i/item/WHO-2019-nCoV-Digital_certificates_diagnostic_test_results-2022.1) is being issued for test result certificates that attests to: (a) the fact that an individual has been tested for SARS-CoV-2, and (b) the result of that SARS-CoV-2 diagnostic test.
 

 The DDCC documents contain overviews of high-level use cases for digital COVID-19 certificates, including: 
* workflows;
* core data elements mapped to standard code systems;
* functional and non-functional requirements;
* an overview of digitally signing and verifying a certificate with public key infrastructure (PKI) technology;
* implementation guidance regarding ethical considerations, privacy and data protection principles;
* national governance considerations;
* and this linked FHIR Implementation Guide for the DDCC scope. 
 

 Supporting guidance, recommendations, resources, and standards are included in the [References](references.md) and [Dependencies](dependencies.md). 

### About this implementation guide

 This implementation guide is broken into the following levels of [knowledge representation](http://hl7.org/fhir/uv/cpg/2019Sep/documentation-approach.html): 
* [Home](index.md) Contains references to the guidance, guidelines, policies and recommendations underpinning this implementation guide.
* [Business Requirements](requirements.md) Contains the requirements for this implementation guide including the definition of key concepts, use cases, and a data dictionary. 
* [Data Models and Exchange](data_exchange.md) Contains the data models and data exchange protocols with actors and transactions defined.
* [Deployment Guidance ](deployment.md) Contains relevant technical specifications and guidance, testing resources, reference implementation materials, and supporting guidance for adaptation to local contexts.
 

### Disclaimer

 The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences. 

