# WHO DDCC Generator - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **WHO DDCC Generator**

## CapabilityStatement: WHO DDCC Generator (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/CapabilityStatement/WHO.DDCC.Generator | *Version*:1.0.0 |
| Draft as of 2021-05-06 | *Computable Name*:WHO_DDCC_Generator |

 
CapabilityStatement for WHO DDCC Generator actor. 

 [Raw OpenAPI-Swagger Definition file](WHO.DDCC.Generator.openapi.json) | [Download](WHO.DDCC.Generator.openapi.json) 

Capability Statement for a DDCC Generator



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "WHO.DDCC.Generator",
  "url" : "http://smart.who.int/ddcc/CapabilityStatement/WHO.DDCC.Generator",
  "version" : "1.0.0",
  "name" : "WHO_DDCC_Generator",
  "title" : "WHO DDCC Generator",
  "status" : "draft",
  "experimental" : true,
  "date" : "2021-05-06",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "CapabilityStatement for WHO DDCC Generator actor.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "kind" : "requirements",
  "fhirVersion" : "4.3.0",
  "format" : ["application/fhir+xml", "application/fhir+json"],
  "rest" : [{
    "mode" : "server",
    "documentation" : "DDCC Generator Server Actor",
    "resource" : [{
      "type" : "QuestionnaireResponse",
      "supportedProfile" : ["http://smart.who.int/ddcc/StructureDefinition/DDCCQuestionnaireResponse"],
      "documentation" : ".",
      "interaction" : [{
        "code" : "create",
        "documentation" : "DDCC Generator Interaction for accepting a Submit Health Event"
      }],
      "operation" : [{
        "name" : "generateHealthCertificate",
        "definition" : "http://smart.who.int/ddcc/OperationDefinition/DDCCQuestionnaireResponsegenerateHealthCertificate",
        "documentation" : "Generate a health certificate based on a QuestionnaireResponse."
      }]
    }],
    "interaction" : [{
      "code" : "batch"
    }]
  },
  {
    "mode" : "client",
    "documentation" : "DDCC Generator Client Actor",
    "interaction" : [{
      "code" : "batch",
      "documentation" : "For submitting the Register Health Certificate transaction."
    }]
  }]
}

```
